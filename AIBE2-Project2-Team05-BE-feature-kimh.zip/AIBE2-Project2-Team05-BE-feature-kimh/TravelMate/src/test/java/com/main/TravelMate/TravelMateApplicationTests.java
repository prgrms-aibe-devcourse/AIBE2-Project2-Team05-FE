package com.main.TravelMate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TravelMateApplicationTests {

	@Test
	void contextLoads() {
	}

}
