package com.main.TravelMate.user.domain;

public enum Role {
    USER, GUIDE, ADMIN
}
